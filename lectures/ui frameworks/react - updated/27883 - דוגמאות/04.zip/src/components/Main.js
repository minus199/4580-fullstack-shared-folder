import React, { Component } from 'react';
import Menu from './Menu';
import Deal from './Deal';

class Main extends Component {



  render() {
    return (
      <div className="col-sm-12">
        <div className="row">
          <Menu listOfItems={["About", "Home", "Contact"]}   ></Menu>
        </div>


        <div className="row">
          <img src={this.props.mainImage.src} className="col-sm-12" title={this.props.mainImage.title} />
        </div>



        <div className="row">
          {this.props.deals.map((deal) => <Deal deal={deal} />)} 
        </div>


      </div>
    );
  }


}

export default Main;
