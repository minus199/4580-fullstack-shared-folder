import React, { Component } from 'react';
import Header from './components/Header';
import Main from './components/Main';
import { Footer } from './components/Footer';

class App extends Component {



  render() {


    let image = {
      title: "bryceTours",
      src: "https://img.maximummedia.ie/her_ie/eyJkYXRhIjoie1widXJsXCI6XCJodHRwOlxcXC9cXFwvbWVkaWEtaGVyLm1heGltdW1tZWRpYS5pZS5zMy5hbWF6b25hd3MuY29tXFxcL3dwLWNvbnRlbnRcXFwvdXBsb2Fkc1xcXC8yMDE3XFxcLzA2XFxcLzI2MTU1MTI0XFxcL2lTdG9jay0xNTU0MzkzMTUxLmpwZ1wiLFwid2lkdGhcIjo3NjcsXCJoZWlnaHRcIjo0MzEsXCJkZWZhdWx0XCI6XCJodHRwczpcXFwvXFxcL3d3dy5oZXIuaWVcXFwvYXNzZXRzXFxcL2ltYWdlc1xcXC9oZXJcXFwvbm8taW1hZ2UucG5nP3Y9NVwifSIsImhhc2giOiI0YTFiNWEzOGQyMGY0OTUzODVjYTdmYmM4NjVlMTRiNGUwMjZhNmQ1In0=/istock-1554393151.jpg"
    }

    return (
      <div className="container">
        <Header title="Bryce Tours" className="row" />
        <Main mainImage={image} className="row" />
        <Footer copy="all rights reseverd. 2018" className="row" />
      </div>

    );
  }
}

export default App;
