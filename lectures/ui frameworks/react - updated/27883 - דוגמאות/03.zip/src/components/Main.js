import React, { Component } from 'react';
import Menu from './Menu';

class Main extends Component {


  constructor(props) {
    super(props);
    this.state={timer:60 };
    this.startCountDown();
  }

  render() {
    return (
      <div className="col-sm-12">
        <div className="row">
          <Menu listOfItems={["About", "Home", "Contact"]}   ></Menu>
        </div>


        <div className="row">
          <img src={this.props.mainImage.src} className="col-sm-12" title={this.props.mainImage.title} />
        </div>



        <div className="row">
          <h1>Time untill this great deal ends: {this.state.timer}</h1>
        </div>


      </div>
    );
  }


  startCountDown()
  {
    setInterval(()=>
    {
      if(this.state.timer>0 )
      {
        let updatedTimer= this.state.timer;
        updatedTimer=updatedTimer-1;
        this.setState({timer:updatedTimer});
      }
    }, 1000)
  }
}

export default Main;
