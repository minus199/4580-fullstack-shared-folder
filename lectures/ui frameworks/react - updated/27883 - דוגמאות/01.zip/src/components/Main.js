import React, { Component } from 'react';

class Main extends Component {
  render() {
    return (
      <h1>Main</h1>
    );
  }
}

export default Main;
