import React, { Component } from 'react';

export function Footer() {

    return (
      <h1>Footer</h1>
    );
  
}


