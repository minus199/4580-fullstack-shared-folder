import React, { Component } from 'react';

class Header extends Component {
  render() {
    return (
      <h1>Header</h1>
    );
  }
}

export default Header;
