import React, { Component } from 'react';

 

class Menu extends Component {

constructor(props)
{
    super(props);  
}


  render() {
    return (
    <div> 
 
      {this.props.listOfItems.map((item) => <div key={item}  className="menu-item">{item}</div>)}  
  
    </div>
    );
  }
}

export default Menu;
