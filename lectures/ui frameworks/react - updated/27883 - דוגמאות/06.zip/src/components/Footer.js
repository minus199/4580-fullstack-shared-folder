import React, { Component } from 'react';

export function Footer(props) {

  return (
    <div className="col-sm-12"> 
      <p>{props.copy}</p>
    </div>
  );

}


