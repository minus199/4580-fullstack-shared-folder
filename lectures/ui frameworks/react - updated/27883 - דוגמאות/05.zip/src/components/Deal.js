import React, { Component } from 'react';



class Deal extends Component {

  timerInerval = null;

  constructor(props) {
    super(props);
    this.state = { timer: this.props.deal.endsIn };

  }

  componentDidMount() {
    this.startCountDown();
  }

  render() {
    return (
      <div className="col-sm-3 deal">

        <h1> {this.props.deal.to}</h1>
        <h5>Ends is: {this.state.timer}</h5>
        <img src={this.props.deal.image} />
        <button  onClick={this.stopTimer.bind(this)} className="btn btn-primary">Buy deal</button>
      </div>
    );
  }

  componentWillUnmount() {
    this.stopTimer();
  }


  startCountDown() {
    this.timerInerval = setInterval(() => {
      if (this.state.timer > 0) {
        let updatedTimer = this.state.timer;
        updatedTimer = updatedTimer - 1;
        this.setState({ timer: updatedTimer });
      }
    }, 1000)
  }


  
  stopTimer() {
   clearInterval(this.timerInerval);
  }

}

export default Deal;
