import React, { Component } from 'react';
import Header from './components/Header';
import Main from './components/Main';
import { Footer } from './components/Footer';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      deals: [
        {
          to: "London",
          endsIn: 95,
          image: "https://media.gettyimages.com/photos/houses-of-parliament-at-night-westminster-london-uk-picture-id508151164"
        },
        {
          to: "Paris",
          endsIn: 60,
          image: "https://d39gusjpdm7p1o.cloudfront.net/data/layout_grouping/static_page_step/20784/a330628091ede7eb1548d6cda58e0357.jpg?ver=1477297804"
        },
        {
          to: "Barcelona",
          endsIn: 78,
          image: "https://images.lucasfox.com/location/4x3_960w/836D68DCBD.jpg"
        }
      ]
    };
  }

  render() {


    let image = {
      title: "bryceTours",
      src: "https://img.maximummedia.ie/her_ie/eyJkYXRhIjoie1widXJsXCI6XCJodHRwOlxcXC9cXFwvbWVkaWEtaGVyLm1heGltdW1tZWRpYS5pZS5zMy5hbWF6b25hd3MuY29tXFxcL3dwLWNvbnRlbnRcXFwvdXBsb2Fkc1xcXC8yMDE3XFxcLzA2XFxcLzI2MTU1MTI0XFxcL2lTdG9jay0xNTU0MzkzMTUxLmpwZ1wiLFwid2lkdGhcIjo3NjcsXCJoZWlnaHRcIjo0MzEsXCJkZWZhdWx0XCI6XCJodHRwczpcXFwvXFxcL3d3dy5oZXIuaWVcXFwvYXNzZXRzXFxcL2ltYWdlc1xcXC9oZXJcXFwvbm8taW1hZ2UucG5nP3Y9NVwifSIsImhhc2giOiI0YTFiNWEzOGQyMGY0OTUzODVjYTdmYmM4NjVlMTRiNGUwMjZhNmQ1In0=/istock-1554393151.jpg"
    }

    return (
      <div className="container">
        <Header title="Bryce Tours" className="row" />
        <Main mainImage={image} className="row"  deals={this.state.deals} />
        <Footer copy="all rights reseverd. 2018" className="row" />
      </div>

    );
  }
}

export default App;
